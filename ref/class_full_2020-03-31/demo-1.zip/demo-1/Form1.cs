﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/*
    Project      Musicians
    Programmer   Mike Mostafavi
    Date         Novt 2019
                
    	         Display name of selected musician
*/

namespace demo_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void ironAndWinePicturBox_Click(object sender, EventArgs e)
        {

            // Displays "Iron and Wine" when this picture is selected
            musicianNameLabel.Text = "Iron and Wine";
        }

        private void mountainGoatsPictureBox_Click(object sender, EventArgs e)
        {
            // Displays "Mountain Goats" when this picture is selected
            musicianNameLabel.Text = "Mountain Goats";
        }

        private void aniDiFrancoPictureBox_Click(object sender, EventArgs e)
        {
            // Displays "ani diFranco" when this picture is selected
            musicianNameLabel.Text = "ani diFranco";
        }

        private void darWilliamsPictureBox_Click(object sender, EventArgs e)
        {
            // Displays "Dar Williams" when this picture is selected
            musicianNameLabel.Text = "Dar Williams";
        }
    }
}
