﻿namespace demo_1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.label1 = new System.Windows.Forms.Label();
            this.musicianNameLabel = new System.Windows.Forms.Label();
            this.ironAndWinePicturBox = new System.Windows.Forms.PictureBox();
            this.aniDiFrancoPictureBox = new System.Windows.Forms.PictureBox();
            this.darWilliamsPictureBox = new System.Windows.Forms.PictureBox();
            this.mountainGoatsPictureBox = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.ironAndWinePicturBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.aniDiFrancoPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.darWilliamsPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mountainGoatsPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(298, 86);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(204, 13);
            this.label1.TabIndex = 21;
            this.label1.Text = "Click on the image to identify the musician";
            // 
            // musicianNameLabel
            // 
            this.musicianNameLabel.Location = new System.Drawing.Point(348, 333);
            this.musicianNameLabel.Name = "musicianNameLabel";
            this.musicianNameLabel.Size = new System.Drawing.Size(104, 32);
            this.musicianNameLabel.TabIndex = 16;
            this.musicianNameLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ironAndWinePicturBox
            // 
            this.ironAndWinePicturBox.Image = ((System.Drawing.Image)(resources.GetObject("ironAndWinePicturBox.Image")));
            this.ironAndWinePicturBox.InitialImage = null;
            this.ironAndWinePicturBox.Location = new System.Drawing.Point(122, 166);
            this.ironAndWinePicturBox.Name = "ironAndWinePicturBox";
            this.ironAndWinePicturBox.Size = new System.Drawing.Size(100, 100);
            this.ironAndWinePicturBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.ironAndWinePicturBox.TabIndex = 20;
            this.ironAndWinePicturBox.TabStop = false;
            this.ironAndWinePicturBox.Click += new System.EventHandler(this.ironAndWinePicturBox_Click);
            // 
            // aniDiFrancoPictureBox
            // 
            this.aniDiFrancoPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("aniDiFrancoPictureBox.Image")));
            this.aniDiFrancoPictureBox.Location = new System.Drawing.Point(412, 166);
            this.aniDiFrancoPictureBox.Name = "aniDiFrancoPictureBox";
            this.aniDiFrancoPictureBox.Size = new System.Drawing.Size(100, 100);
            this.aniDiFrancoPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.aniDiFrancoPictureBox.TabIndex = 18;
            this.aniDiFrancoPictureBox.TabStop = false;
            this.aniDiFrancoPictureBox.Click += new System.EventHandler(this.aniDiFrancoPictureBox_Click);
            // 
            // darWilliamsPictureBox
            // 
            this.darWilliamsPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("darWilliamsPictureBox.Image")));
            this.darWilliamsPictureBox.InitialImage = null;
            this.darWilliamsPictureBox.Location = new System.Drawing.Point(557, 166);
            this.darWilliamsPictureBox.Name = "darWilliamsPictureBox";
            this.darWilliamsPictureBox.Size = new System.Drawing.Size(122, 100);
            this.darWilliamsPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.darWilliamsPictureBox.TabIndex = 19;
            this.darWilliamsPictureBox.TabStop = false;
            this.darWilliamsPictureBox.Click += new System.EventHandler(this.darWilliamsPictureBox_Click);
            // 
            // mountainGoatsPictureBox
            // 
            this.mountainGoatsPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("mountainGoatsPictureBox.Image")));
            this.mountainGoatsPictureBox.InitialImage = null;
            this.mountainGoatsPictureBox.Location = new System.Drawing.Point(267, 166);
            this.mountainGoatsPictureBox.Name = "mountainGoatsPictureBox";
            this.mountainGoatsPictureBox.Size = new System.Drawing.Size(100, 100);
            this.mountainGoatsPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.mountainGoatsPictureBox.TabIndex = 17;
            this.mountainGoatsPictureBox.TabStop = false;
            this.mountainGoatsPictureBox.Click += new System.EventHandler(this.mountainGoatsPictureBox_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.musicianNameLabel);
            this.Controls.Add(this.ironAndWinePicturBox);
            this.Controls.Add(this.aniDiFrancoPictureBox);
            this.Controls.Add(this.darWilliamsPictureBox);
            this.Controls.Add(this.mountainGoatsPictureBox);
            this.Name = "Form1";
            this.Text = "Demo-1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.ironAndWinePicturBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.aniDiFrancoPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.darWilliamsPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mountainGoatsPictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        internal System.Windows.Forms.Label musicianNameLabel;
        internal System.Windows.Forms.PictureBox ironAndWinePicturBox;
        internal System.Windows.Forms.PictureBox aniDiFrancoPictureBox;
        internal System.Windows.Forms.PictureBox darWilliamsPictureBox;
        internal System.Windows.Forms.PictureBox mountainGoatsPictureBox;
    }
}

